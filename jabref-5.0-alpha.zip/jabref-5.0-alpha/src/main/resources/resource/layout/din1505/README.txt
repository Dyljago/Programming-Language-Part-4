Custom Export for DIN1505 style by Thorsten Bothe

This is a custom export to allow a reference output in DIN1505 conform style. That means e.g. authors in capitals and Book/article title in italic.

This export is not yet complete and some issues cannot be resolved without extension of the internal format modifier. E. g. the last author is separates by '&' but should have a ',' only.

At least this could be helpful for writing German documents outside TeX (which has working DIN1505 TeX styles) like OO and Word. Some manual postprocessing necessary.