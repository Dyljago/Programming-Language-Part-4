package org.jabref.gui;

public class AbstractViewModel {
    //empty
}
