/**
 * This package contains stubs for oracle.jdbc to prevent build errors if the non-distributable oraclejdbdc6.jar is unavailable in the classpath
 */
package oracle.jdbc;
